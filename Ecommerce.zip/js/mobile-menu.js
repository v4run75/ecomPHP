$(document).ready(function(){
    $(".fa-bars").on("click",function(){
       $("header nav ul").toggleClass("open");
       });
});