<?php


class ProductModel extends CI_Model
{
    public function getCategoriesFromTable()
    {
        $this->db->select('*');
        $this->db->from('categories');

        $query = $this->db->get();

        return $query->result_array();
    }

    public function getSubCategoriesFromTable($cat_id)
    {
        $this->db->select('subcat_id,name,image');
        $this->db->from('subcategories');
        $this->db->where('cat_id',$cat_id);

        $query = $this->db->get();

        return $query->result_array();
    }

    public function getProductsFromTable($subcat_id)
    {
        $this->db->select('*');
        $this->db->from('products');
        $this->db->where('subcat_id',$subcat_id);

        $query = $this->db->get();

        return $query->result_array();
    }

    public function getAllProductsFromTable()
    {
        $this->db->select('*');
        $this->db->from('products');

        $query = $this->db->get();

        return $query->result_array();
    }
}